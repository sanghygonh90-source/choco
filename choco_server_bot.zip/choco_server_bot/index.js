require("dotenv").config();

const Database = require("better-sqlite3");
const {
  Client, GatewayIntentBits, Partials, REST, Routes,
  SlashCommandBuilder, PermissionFlagsBits, ChannelType,
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, ModalBuilder, TextInputBuilder,
  TextInputStyle, Events
} = require("discord.js");

const required = ["DISCORD_TOKEN", "CLIENT_ID", "GUILD_ID"];
for (const key of required) {
  if (!process.env[key]) {
    console.error(`환경변수 ${key}가 비어 있습니다. .env를 확인하세요.`);
    process.exit(1);
  }
}

const db = new Database("choco.sqlite");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL,
 price INTEGER NOT NULL, stock INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL, channel_id TEXT,
 product_id INTEGER NOT NULL, product_name TEXT NOT NULL, quantity INTEGER NOT NULL,
 nickname TEXT NOT NULL, unit_price INTEGER NOT NULL, total INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'draft', created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS warnings (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL, moderator_id TEXT NOT NULL,
 reason TEXT NOT NULL, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS stats (
 user_id TEXT PRIMARY KEY, xp INTEGER NOT NULL DEFAULT 0, level INTEGER NOT NULL DEFAULT 0,
 coins INTEGER NOT NULL DEFAULT 0, attendance TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS donations (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL, amount INTEGER NOT NULL,
 note TEXT NOT NULL DEFAULT '', moderator_id TEXT NOT NULL, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS events (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT NOT NULL,
 created_by TEXT NOT NULL, created_at INTEGER NOT NULL, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS event_entries (
 event_id INTEGER NOT NULL, user_id TEXT NOT NULL, PRIMARY KEY(event_id,user_id)
);
`);
const getSetting = key => db.prepare("SELECT value FROM settings WHERE key=?").get(key)?.value || "";
const setSetting = (key, value) => db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(key, String(value));
const isStaff = interaction => interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild) ||
  (getSetting("staff_role_id") && interaction.member?.roles?.cache?.has(getSetting("staff_role_id")));
const fmt = n => Number(n).toLocaleString("ko-KR");
const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMembers],
  partials: [Partials.Channel]
});

function logEmbed(title, description, color=0x8B5E3C) {
  return new EmbedBuilder().setTitle(title).setDescription(description).setColor(color).setTimestamp();
}
async function sendLog(guild, title, description) {
  const id = getSetting("log_channel_id") || process.env.LOG_CHANNEL_ID;
  if (!id || !guild) return;
  const channel = await guild.channels.fetch(id).catch(() => null);
  if (channel?.isTextBased()) await channel.send({embeds:[logEmbed(title, description)]}).catch(()=>{});
}
function staffOnly(i) {
  if (isStaff(i)) return false;
  i.reply({content:"이 명령어는 운영진만 사용할 수 있어요.",ephemeral:true}).catch(()=>{});
  return true;
}
function statsFor(userId) {
  db.prepare("INSERT OR IGNORE INTO stats(user_id) VALUES(?)").run(userId);
  return db.prepare("SELECT * FROM stats WHERE user_id=?").get(userId);
}
function orderEmbed(o) {
  return new EmbedBuilder().setTitle("🍫 초코종합서버 | 구매 티켓")
    .setColor(0x8B5E3C)
    .addFields(
      {name:"주문 번호",value:o.id ? `CHOCO-${o.id}` : "확정 전",inline:true},
      {name:"상품",value:o.product_name || "선택 전",inline:true},
      {name:"수량",value:`${o.quantity || 1}개`,inline:true},
      {name:"로블록스 닉네임",value:o.nickname || "미입력",inline:true},
      {name:"상품 단가",value:o.unit_price == null ? "선택 전" : `${fmt(o.unit_price)} ${getSetting("currency_label") || process.env.CURRENCY_LABEL || "원"}`,inline:true},
      {name:"총 결제 금액",value:o.total == null ? "선택 전" : `${fmt(o.total)} ${getSetting("currency_label") || process.env.CURRENCY_LABEL || "원"}`,inline:true},
      {name:"상태",value:o.status || "상품 확인 중"}
    ).setFooter({text:"송금 완료 버튼은 입금 증명이 아니며 운영진 확인 후 승인됩니다."});
}
function ticketComponents(products) {
  const rows = [];
  if (products.length) {
    rows.push(new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder().setCustomId("order_product").setPlaceholder("구매할 상품 선택")
        .addOptions(products.slice(0,25).map(p=>({label:p.name.slice(0,100),description:`단가 ${fmt(p.price)} · 재고 ${p.stock}`,value:String(p.id)})))
    ));
  }
  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("order_quantity").setLabel("수량 변경").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("order_nickname").setLabel("닉네임 수정").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("order_confirm").setLabel("주문 확정").setStyle(ButtonStyle.Success)
  ));
  return rows;
}
const commandDefs = [
 new SlashCommandBuilder().setName("구매티켓").setDescription("구매 티켓 생성"),
 new SlashCommandBuilder().setName("문의티켓").setDescription("일반 문의 티켓 생성"),
 new SlashCommandBuilder().setName("상품등록").setDescription("샵 상품 등록").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
   .addStringOption(o=>o.setName("상품명").setDescription("상품 이름").setRequired(true))
   .addIntegerOption(o=>o.setName("가격").setDescription("개당 가격").setMinValue(0).setRequired(true))
   .addIntegerOption(o=>o.setName("재고").setDescription("재고 수량").setMinValue(0).setRequired(true)),
 new SlashCommandBuilder().setName("상품목록").setDescription("상품과 재고 확인"),
 new SlashCommandBuilder().setName("재고변경").setDescription("상품 재고 변경").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
   .addIntegerOption(o=>o.setName("상품번호").setDescription("상품 ID").setRequired(true))
   .addIntegerOption(o=>o.setName("재고").setDescription("새 재고").setMinValue(0).setRequired(true)),
 new SlashCommandBuilder().setName("설정").setDescription("봇 채널/역할 설정").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
   .addStringOption(o=>o.setName("항목").setDescription("설정 항목").setRequired(true).addChoices(
    {name:"로그 채널",value:"log_channel_id"},{name:"환영 채널",value:"welcome_channel_id"},
    {name:"티켓 카테고리",value:"ticket_category_id"},{name:"운영진 역할",value:"staff_role_id"},
    {name:"결제 확인 채널",value:"payment_review_channel_id"},{name:"은행명",value:"bank_name"},
    {name:"예금주",value:"account_holder"},{name:"계좌번호",value:"account_number"},
    {name:"가격 단위",value:"currency_label"},{name:"인증 완료 역할",value:"verified_role_id"}))
   .addStringOption(o=>o.setName("값").setDescription("채널/역할 ID 또는 표시할 값").setRequired(true)),
 new SlashCommandBuilder().setName("공지").setDescription("공지 메시지 전송").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
   .addChannelOption(o=>o.setName("채널").setDescription("보낼 채널").addChannelTypes(ChannelType.GuildText).setRequired(true))
   .addStringOption(o=>o.setName("제목").setDescription("공지 제목").setRequired(true))
   .addStringOption(o=>o.setName("내용").setDescription("공지 내용").setRequired(true)),
 new SlashCommandBuilder().setName("경고").setDescription("회원에게 경고 부여").setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
   .addUserOption(o=>o.setName("회원").setDescription("대상 회원").setRequired(true))
   .addStringOption(o=>o.setName("사유").setDescription("경고 사유").setRequired(true)),
 new SlashCommandBuilder().setName("경고조회").setDescription("회원 경고 내역 조회").setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
   .addUserOption(o=>o.setName("회원").setDescription("조회할 회원").setRequired(true)),
 new SlashCommandBuilder().setName("역할지급").setDescription("회원에게 역할 지급").setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
   .addUserOption(o=>o.setName("회원").setDescription("대상 회원").setRequired(true))
   .addRoleOption(o=>o.setName("역할").setDescription("지급할 역할").setRequired(true)),
 new SlashCommandBuilder().setName("메시지삭제").setDescription("최근 메시지 삭제").setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
   .addIntegerOption(o=>o.setName("개수").setDescription("1~100개").setMinValue(1).setMaxValue(100).setRequired(true)),
 new SlashCommandBuilder().setName("인증패널").setDescription("인증 버튼 패널 생성").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
 new SlashCommandBuilder().setName("규칙패널").setDescription("규칙 안내 패널 생성").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
   .addStringOption(o=>o.setName("내용").setDescription("서버 규칙").setRequired(true)),
 new SlashCommandBuilder().setName("역할패널").setDescription("역할 선택 안내").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
   .addStringOption(o=>o.setName("내용").setDescription("역할 선택 안내 내용").setRequired(true)),
 new SlashCommandBuilder().setName("후원방법").setDescription("후원 방법 안내")
   .addStringOption(o=>o.setName("내용").setDescription("후원 방법").setRequired(false)),
 new SlashCommandBuilder().setName("후원기록").setDescription("후원 내역 기록").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
   .addUserOption(o=>o.setName("회원").setDescription("후원자").setRequired(true))
   .addIntegerOption(o=>o.setName("금액").setDescription("확인된 후원 금액").setMinValue(1).setRequired(true))
   .addStringOption(o=>o.setName("메모").setDescription("선택 메모").setRequired(false)),
 new SlashCommandBuilder().setName("후원랭킹").setDescription("후원 랭킹 조회"),
 new SlashCommandBuilder().setName("구매랭킹").setDescription("완료된 구매 랭킹 조회"),
 new SlashCommandBuilder().setName("채팅랭킹").setDescription("채팅 경험치 랭킹 조회"),
 new SlashCommandBuilder().setName("결제확인").setDescription("입금 확인 후 주문 승인").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
   .addIntegerOption(o=>o.setName("주문번호").setDescription("숫자 주문 ID").setRequired(true)),
 new SlashCommandBuilder().setName("주문상태").setDescription("주문 상태 확인")
   .addIntegerOption(o=>o.setName("주문번호").setDescription("숫자 주문 ID").setRequired(true)),
 new SlashCommandBuilder().setName("이벤트생성").setDescription("이벤트 생성").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
   .addStringOption(o=>o.setName("제목").setDescription("이벤트 제목").setRequired(true))
   .addStringOption(o=>o.setName("내용").setDescription("이벤트 내용").setRequired(true)),
 new SlashCommandBuilder().setName("이벤트참여").setDescription("진행 중인 이벤트 참여")
   .addIntegerOption(o=>o.setName("이벤트번호").setDescription("이벤트 ID").setRequired(true)),
 new SlashCommandBuilder().setName("출석").setDescription("오늘 출석하고 가상 코인 받기"),
 new SlashCommandBuilder().setName("잔액").setDescription("내 가상 코인 잔액 확인"),
 new SlashCommandBuilder().setName("코인송금").setDescription("서버 내 가상 코인 보내기")
   .addUserOption(o=>o.setName("회원").setDescription("받는 회원").setRequired(true))
   .addIntegerOption(o=>o.setName("금액").setDescription("보낼 코인").setMinValue(1).setRequired(true)),
 new SlashCommandBuilder().setName("가위바위보").setDescription("가상 코인으로 가위바위보")
   .addStringOption(o=>o.setName("선택").setDescription("가위/바위/보").setRequired(true).addChoices(
    {name:"가위",value:"가위"},{name:"바위",value:"바위"},{name:"보",value:"보"}))
   .addIntegerOption(o=>o.setName("금액").setDescription("베팅할 가상 코인").setMinValue(1).setRequired(true)),
 new SlashCommandBuilder().setName("주사위").setDescription("주사위 굴리기"),
 new SlashCommandBuilder().setName("레벨").setDescription("내 채팅 레벨 확인")
];

client.on(Events.GuildMemberAdd, async member => {
  const channelId = getSetting("welcome_channel_id") || process.env.WELCOME_CHANNEL_ID;
  const channel = channelId ? await member.guild.channels.fetch(channelId).catch(()=>null) : null;
  if (channel?.isTextBased()) channel.send(`🍫 ${member}님, 초코종합서버에 오신 것을 환영해요! 인증을 완료해 주세요.`).catch(()=>{});
  await sendLog(member.guild, "📥 회원 입장", `${member.user.tag} (${member.id})`);
});
client.on(Events.GuildMemberRemove, async member => sendLog(member.guild, "📤 회원 퇴장", `${member.user?.tag || "알 수 없음"} (${member.id})`));
client.on(Events.GuildAuditLogEntryCreate, async (entry, guild) => {
  await sendLog(guild, "🛡️ 관리 로그", `작업자 ID: ${entry.executorId || "알 수 없음"}\n대상 ID: ${entry.targetId || "없음"}\n작업: ${entry.action}`);
});

client.on(Events.MessageCreate, async message => {
  if (!message.guild || message.author.bot) return;
  const row = statsFor(message.author.id);
  const xpGain = 5 + Math.floor(Math.random()*6);
  const newXp = row.xp + xpGain;
  const newLevel = Math.floor(Math.sqrt(newXp / 100));
  db.prepare("UPDATE stats SET xp=?, level=? WHERE user_id=?").run(newXp,newLevel,message.author.id);
  if (newLevel > row.level) {
    message.channel.send(`🎉 <@${message.author.id}> 레벨 ${newLevel} 달성!`).catch(()=>{});
  }
});

client.on(Events.InteractionCreate, async i => {
 try {
  if (i.isChatInputCommand()) {
   const name = i.commandName;
   if (name === "구매티켓" || name === "문의티켓") {
    const category = getSetting("ticket_category_id") || process.env.TICKET_CATEGORY_ID || undefined;
    const overwrites = [
      {id:i.guild.id,deny:[PermissionFlagsBits.ViewChannel]},
      {id:i.user.id,allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory]},
      {id:client.user.id,allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory,PermissionFlagsBits.ManageChannels]}
    ];
    const staffRole = getSetting("staff_role_id") || process.env.STAFF_ROLE_ID;
    if (staffRole) overwrites.push({id:staffRole,allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory]});
    const ch = await i.guild.channels.create({
      name:`${name==="구매티켓"?"구매":"문의"}-${i.user.username}`.toLowerCase().replace(/[^a-z0-9가-힣-]/g,"-").slice(0,90),
      type:ChannelType.GuildText, parent:category, permissionOverwrites:overwrites
    });
    if (name === "문의티켓") {
      await ch.send({content:`<@${i.user.id}> 문의 내용을 작성해 주세요. 운영진이 확인할게요.`,embeds:[logEmbed("💬 초코종합서버 | 문의 티켓","문의 내용과 관련 정보를 남겨 주세요.")]});
    } else {
      const products = db.prepare("SELECT * FROM products WHERE active=1 ORDER BY id DESC").all();
      await ch.send({content:`<@${i.user.id}> 구매할 상품을 선택해 주세요.`,embeds:[orderEmbed({quantity:1,status:"상품 확인 중"})],components:ticketComponents(products)});
    }
    return i.reply({content:`티켓을 생성했어요: ${ch}`,ephemeral:true});
   }

   if (name === "설정") {
    if (staffOnly(i)) return;
    setSetting(i.options.getString("항목"), i.options.getString("값"));
    return i.reply({content:`설정을 저장했어요: ${i.options.getString("항목")}`,ephemeral:true});
   }
   if (name === "상품등록") {
    if (staffOnly(i)) return;
    const productName=i.options.getString("상품명"), price=i.options.getInteger("가격"), stock=i.options.getInteger("재고");
    db.prepare("INSERT INTO products(name,price,stock) VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET price=excluded.price,stock=excluded.stock,active=1").run(productName,price,stock);
    return i.reply({content:`상품을 등록/수정했어요: ${productName} · 단가 ${fmt(price)} · 재고 ${stock}`,ephemeral:true});
   }
   if (name === "상품목록") {
    const ps=db.prepare("SELECT * FROM products WHERE active=1 ORDER BY id").all();
    return i.reply({embeds:[logEmbed("🛒 초코종합서버 상품 목록",ps.length?ps.map(p=>`**#${p.id} ${p.name}** · ${fmt(p.price)} · 재고 ${p.stock}`).join("\n"):"등록된 상품이 없습니다.")],ephemeral:true});
   }
   if (name === "재고변경") {
    if (staffOnly(i)) return;
    const id=i.options.getInteger("상품번호"), stock=i.options.getInteger("재고");
    const r=db.prepare("UPDATE products SET stock=? WHERE id=?").run(stock,id);
    return i.reply({content:r.changes?`상품 #${id} 재고를 ${stock}개로 변경했어요.`:"상품 번호를 찾을 수 없어요.",ephemeral:true});
   }
   if (name === "공지") {
    if (staffOnly(i)) return;
    const ch=i.options.getChannel("채널");
    await ch.send({embeds:[new EmbedBuilder().setTitle(i.options.getString("제목")).setDescription(i.options.getString("내용")).setColor(0x8B5E3C).setTimestamp()]});
    await sendLog(i.guild,"📢 공지 전송",`작성자: ${i.user.tag}\n채널: ${ch}`);
    return i.reply({content:"공지를 전송했어요.",ephemeral:true});
   }
   if (name === "경고") {
    if (staffOnly(i)) return;
    const user=i.options.getUser("회원"), reason=i.options.getString("사유");
    db.prepare("INSERT INTO warnings(user_id,moderator_id,reason,created_at) VALUES(?,?,?,?)").run(user.id,i.user.id,reason,Date.now());
    await sendLog(i.guild,"⚠️ 경고 부여",`회원: ${user.tag}\n운영진: ${i.user.tag}\n사유: ${reason}`);
    return i.reply({content:`${user.tag}님에게 경고를 기록했어요.`,ephemeral:true});
   }
   if (name === "경고조회") {
    if (staffOnly(i)) return;
    const user=i.options.getUser("회원");
    const ws=db.prepare("SELECT * FROM warnings WHERE user_id=? ORDER BY id DESC LIMIT 10").all(user.id);
    return i.reply({embeds:[logEmbed(`⚠️ ${user.tag} 경고 내역`,ws.length?ws.map(w=>`#${w.id} · ${w.reason} · <t:${Math.floor(w.created_at/1000)}:R>`).join("\n"):"경고 내역이 없습니다.")],ephemeral:true});
   }
   if (name === "역할지급") {
    if (staffOnly(i)) return;
    const user=i.options.getUser("회원"), role=i.options.getRole("역할");
    const member=await i.guild.members.fetch(user.id);
    await member.roles.add(role);
    await sendLog(i.guild,"🎭 역할 지급",`${user.tag} ← ${role.name} · 실행자 ${i.user.tag}`);
    return i.reply({content:`${user.tag}님에게 ${role.name} 역할을 지급했어요.`,ephemeral:true});
   }
   if (name === "메시지삭제") {
    if (staffOnly(i)) return;
    const count=i.options.getInteger("개수");
    const deleted=await i.channel.bulkDelete(count,true);
    await sendLog(i.guild,"🧹 메시지 삭제",`${i.user.tag}님이 ${deleted.size}개 메시지를 삭제했어요.`);
    return i.reply({content:`${deleted.size}개 메시지를 삭제했어요.`,ephemeral:true});
   }
   if (name === "인증패널") {
    if (staffOnly(i)) return;
    const row=new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("verify_member").setLabel("인증 완료").setStyle(ButtonStyle.Success));
    await i.channel.send({embeds:[logEmbed("🔐 초코종합서버 인증","아래 버튼을 눌러 인증 역할을 받아 주세요.")],components:[row]});
    return i.reply({content:"인증 패널을 만들었어요. 인증 역할은 /설정으로 등록해야 해요.",ephemeral:true});
   }
   if (name === "규칙패널" || name === "역할패널") {
    if (staffOnly(i)) return;
    await i.channel.send({embeds:[logEmbed(name==="규칙패널"?"📜 서버 규칙":"🎭 역할 안내",i.options.getString("내용"))]});
    return i.reply({content:"패널을 게시했어요.",ephemeral:true});
   }
   if (name === "후원방법") {
    const content=i.options.getString("내용") || "후원 방법은 운영진에게 문의해 주세요. 후원은 자발적으로 진행해 주세요.";
    return i.reply({embeds:[logEmbed("💝 초코종합서버 후원 안내",content)],ephemeral:true});
   }
   if (name === "후원기록") {
    if (staffOnly(i)) return;
    const user=i.options.getUser("회원"), amount=i.options.getInteger("금액"), note=i.options.getString("메모")||"";
    db.prepare("INSERT INTO donations(user_id,amount,note,moderator_id,created_at) VALUES(?,?,?,?,?)").run(user.id,amount,note,i.user.id,Date.now());
    await sendLog(i.guild,"💝 후원 기록",`${user.tag} · ${fmt(amount)} · ${note}`);
    return i.reply({content:`${user.tag}님의 후원을 기록했어요.`,ephemeral:true});
   }
   if (name === "후원랭킹") {
    const rows=db.prepare("SELECT user_id,SUM(amount) total FROM donations GROUP BY user_id ORDER BY total DESC LIMIT 10").all();
    return i.reply({embeds:[logEmbed("💝 후원 랭킹",rows.length?rows.map((r,n)=>`${n+1}. <@${r.user_id}> · ${fmt(r.total)}`).join("\n"):"아직 기록이 없습니다.") ]});
   }
   if (name === "구매랭킹") {
    const rows=db.prepare("SELECT user_id,SUM(total) total FROM orders WHERE status='completed' GROUP BY user_id ORDER BY total DESC LIMIT 10").all();
    return i.reply({embeds:[logEmbed("🛒 구매 랭킹",rows.length?rows.map((r,n)=>`${n+1}. <@${r.user_id}> · ${fmt(r.total)}`).join("\n"):"완료된 구매가 없습니다.") ]});
   }
   if (name === "채팅랭킹") {
    const rows=db.prepare("SELECT user_id,xp,level FROM stats ORDER BY xp DESC LIMIT 10").all();
    return i.reply({embeds:[logEmbed("🏆 채팅 랭킹",rows.length?rows.map((r,n)=>`${n+1}. <@${r.user_id}> · 레벨 ${r.level} · XP ${r.xp}`).join("\n"):"아직 기록이 없습니다.") ]});
   }
   if (name === "결제확인") {
    if (staffOnly(i)) return;
    const id=i.options.getInteger("주문번호"), o=db.prepare("SELECT * FROM orders WHERE id=?").get(id);
    if (!o) return i.reply({content:"주문 번호를 찾을 수 없어요.",ephemeral:true});
    if (o.status!=="payment_pending") return i.reply({content:`현재 상태는 ${o.status}입니다. 결제 대기 주문만 승인할 수 있어요.`,ephemeral:true});
    const tx=db.transaction(()=>{
      const current=db.prepare("SELECT stock FROM products WHERE id=?").get(o.product_id);
      if (!current || current.stock < o.quantity) throw new Error("재고가 부족합니다.");
      db.prepare("UPDATE products SET stock=stock-? WHERE id=?").run(o.quantity,o.product_id);
      db.prepare("UPDATE orders SET status='completed' WHERE id=?").run(id);
    });
    try { tx(); } catch(e) { return i.reply({content:`승인하지 못했어요: ${e.message}`,ephemeral:true}); }
    await sendLog(i.guild,"✅ 주문 결제 확인",`주문 #${id} · 회원 <@${o.user_id}> · ${fmt(o.total)}`);
    return i.reply({content:`주문 #${id} 입금 확인 및 주문 완료 처리했어요.`,ephemeral:true});
   }
   if (name === "주문상태") {
    const id=i.options.getInteger("주문번호"), o=db.prepare("SELECT * FROM orders WHERE id=?").get(id);
    if (!o || (o.user_id!==i.user.id && !isStaff(i))) return i.reply({content:"주문을 찾을 수 없거나 조회 권한이 없어요.",ephemeral:true});
    return i.reply({embeds:[logEmbed(`주문 #${o.id}`,`상품: ${o.product_name}\n수량: ${o.quantity}\n총금액: ${fmt(o.total)}\n상태: ${o.status}`)],ephemeral:true});
   }
   if (name === "이벤트생성") {
    if (staffOnly(i)) return;
    const title=i.options.getString("제목"), description=i.options.getString("내용");
    const result=db.prepare("INSERT INTO events(title,description,created_by,created_at) VALUES(?,?,?,?)").run(title,description,i.user.id,Date.now());
    const row=new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`event_join_${result.lastInsertRowid}`).setLabel("이벤트 참여").setStyle(ButtonStyle.Primary));
    await i.channel.send({embeds:[logEmbed(`🎉 이벤트 #${result.lastInsertRowid}: ${title}`,description)],components:[row]});
    return i.reply({content:`이벤트 #${result.lastInsertRowid}를 생성했어요.`,ephemeral:true});
   }
   if (name === "이벤트참여") {
    const id=i.options.getInteger("이벤트번호");
    const ev=db.prepare("SELECT * FROM events WHERE id=? AND active=1").get(id);
    if (!ev) return i.reply({content:"진행 중인 이벤트를 찾을 수 없어요.",ephemeral:true});
    db.prepare("INSERT OR IGNORE INTO event_entries(event_id,user_id) VALUES(?,?)").run(id,i.user.id);
    return i.reply({content:`이벤트 **${ev.title}** 참여를 기록했어요!`,ephemeral:true});
   }
   if (name === "출석") {
    const s=statsFor(i.user.id), today=new Date().toISOString().slice(0,10);
    if (s.attendance===today) return i.reply({content:"오늘은 이미 출석했어요.",ephemeral:true});
    db.prepare("UPDATE stats SET coins=coins+100,attendance=? WHERE user_id=?").run(today,i.user.id);
    return i.reply({content:"출석 완료! 가상 코인 100개를 받았어요. 🎁",ephemeral:true});
   }
   if (name === "잔액") return i.reply({content:`보유 가상 코인: **${fmt(statsFor(i.user.id).coins)}**`,ephemeral:true});
   if (name === "코인송금") {
    const target=i.options.getUser("회원"), amount=i.options.getInteger("금액");
    if (target.bot || target.id===i.user.id) return i.reply({content:"자기 자신이나 봇에게는 보낼 수 없어요.",ephemeral:true});
    const tx=db.transaction(()=>{
      const sender=statsFor(i.user.id);
      if (sender.coins<amount) throw new Error("코인이 부족해요.");
      statsFor(target.id);
      db.prepare("UPDATE stats SET coins=coins-? WHERE user_id=?").run(amount,i.user.id);
      db.prepare("UPDATE stats SET coins=coins+? WHERE user_id=?").run(amount,target.id);
    });
    try {tx();} catch(e){return i.reply({content:e.message,ephemeral:true});}
    return i.reply({content:`<@${target.id}>님에게 가상 코인 ${amount}개를 보냈어요.`,ephemeral:true});
   }
   if (name === "가위바위보") {
    const s=statsFor(i.user.id), choice=i.options.getString("선택"), amount=i.options.getInteger("금액");
    if (s.coins<amount) return i.reply({content:"가상 코인이 부족해요.",ephemeral:true});
    const choices=["가위","바위","보"], bot=choices[Math.floor(Math.random()*3)];
    const result=choice===bot?"무승부":((choice==="가위"&&bot==="보")||(choice==="바위"&&bot==="가위")||(choice==="보"&&bot==="바위"))?"승리":"패배";
    const delta=result==="승리"?amount:result==="패배"?-amount:0;
    db.prepare("UPDATE stats SET coins=coins+? WHERE user_id=?").run(delta,i.user.id);
    return i.reply({content:`너: ${choice} · 봇: ${bot}\n결과: **${result}**\n변동: ${delta>0?"+":""}${delta} 가상 코인`,ephemeral:true});
   }
   if (name === "주사위") return i.reply(`🎲 ${i.user}님의 결과: **${1+Math.floor(Math.random()*6)}**`);
   if (name === "레벨") {
    const s=statsFor(i.user.id);
    return i.reply({embeds:[logEmbed("🏆 내 레벨",`레벨: ${s.level}\n경험치: ${s.xp}\n다음 레벨까지 약 ${Math.max(0,(s.level+1)**2*100-s.xp)} XP`)],ephemeral:true});
   }
  }

  // ===== 버튼 상호작용 =====
  if (i.isButton()) {
   if (i.customId === "verify_member") {
    const roleId=getSetting("verified_role_id");
    if (!roleId) return i.reply({content:"운영진이 인증 역할 ID를 설정해야 해요.",ephemeral:true});
    await i.member.roles.add(roleId);
    return i.reply({content:"인증 완료! 환영합니다. 🍫",ephemeral:true});
   }
   if (i.customId.startsWith("event_join_")) {
    const id=Number(i.customId.replace("event_join_",""));
    const ev=db.prepare("SELECT * FROM events WHERE id=? AND active=1").get(id);
    if (!ev) return i.reply({content:"이벤트가 종료되었어요.",ephemeral:true});
    db.prepare("INSERT OR IGNORE INTO event_entries(event_id,user_id) VALUES(?,?)").run(id,i.user.id);
    return i.reply({content:`이벤트 **${ev.title}** 참여 완료!`,ephemeral:true});
   }
   if (["order_quantity","order_nickname"].includes(i.customId)) {
    const modal=new ModalBuilder().setCustomId(i.customId+"_modal").setTitle(i.customId==="order_quantity"?"수량 변경":"닉네임 수정");
    const input=new TextInputBuilder().setCustomId("value").setLabel(i.customId==="order_quantity"?"수량 (1~100)":"로블록스 닉네임")
      .setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(i.customId==="order_quantity"?3:50);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    return i.showModal(modal);
   }
   if (i.customId==="order_confirm") {
    const draft=db.prepare("SELECT * FROM orders WHERE channel_id=? AND status='draft' ORDER BY id DESC LIMIT 1").get(i.channelId);
    if (!draft) return i.reply({content:"먼저 상품을 선택하고 닉네임을 입력해 주세요.",ephemeral:true});
    if (draft.user_id!==i.user.id) return i.reply({content:"구매자만 주문을 확정할 수 있어요.",ephemeral:true});
    const product=db.prepare("SELECT * FROM products WHERE id=? AND active=1").get(draft.product_id);
    if (!product) return i.reply({content:"상품이 없거나 판매 중지 상태예요.",ephemeral:true});
    if (draft.quantity>product.stock) return i.reply({content:`재고가 부족해요. 현재 재고: ${product.stock}`,ephemeral:true});
    const total=product.price*draft.quantity;
    db.prepare("UPDATE orders SET unit_price=?,total=?,status='confirmed' WHERE id=?").run(product.price,total,draft.id);
    await i.update({embeds:[orderEmbed({...draft,unit_price:product.price,total,status:"주문 확정 · 결제 안내 대기"})],components:[]});
    const delay=Math.max(0,Number(process.env.PAYMENT_DELAY_SECONDS||90))*1000;
    setTimeout(async()=>{
      const fresh=db.prepare("SELECT * FROM orders WHERE id=?").get(draft.id);
      if (!fresh || fresh.status!=="confirmed") return;
      const bank=getSetting("bank_name")||process.env.BANK_NAME||"운영자 설정 필요";
      const holder=getSetting("account_holder")||process.env.ACCOUNT_HOLDER||"운영자 설정 필요";
      const account=getSetting("account_number")||process.env.ACCOUNT_NUMBER||"운영자 설정 필요";
      const row=new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`payment_sent_${fresh.id}`).setLabel("송금 완료").setStyle(ButtonStyle.Primary));
      const ch=await client.channels.fetch(fresh.channel_id).catch(()=>null);
      if (ch) await ch.send({content:`<@${fresh.user_id}> 결제 안내입니다.\n은행: ${bank}\n예금주: ${holder}\n계좌번호: ${account}\n입금 금액: **${fmt(fresh.total)} ${getSetting("currency_label")||process.env.CURRENCY_LABEL||"원"}**\n\n송금 후 아래 버튼을 눌러 주세요. 버튼 클릭만으로 결제가 확정되지는 않으며 운영진이 입금 내역을 확인합니다.`,components:[row]});
    },delay);
    return;
   }
   if (i.customId.startsWith("payment_sent_")) {
    const id=Number(i.customId.replace("payment_sent_",""));
    const o=db.prepare("SELECT * FROM orders WHERE id=?").get(id);
    if (!o || o.user_id!==i.user.id) return i.reply({content:"이 주문의 구매자만 사용할 수 있어요.",ephemeral:true});
    if (!["confirmed","payment_pending"].includes(o.status)) return i.reply({content:`현재 주문 상태: ${o.status}`,ephemeral:true});
    db.prepare("UPDATE orders SET status='payment_pending' WHERE id=?").run(id);
    const reviewId=getSetting("payment_review_channel_id")||process.env.PAYMENT_REVIEW_CHANNEL_ID;
    const review=reviewId?await client.channels.fetch(reviewId).catch(()=>null):null;
    if (review?.isTextBased()) await review.send({content:`🔔 송금 확인 요청 · 주문 #${id}\n구매자: <@${o.user_id}>\n금액: ${fmt(o.total)}\n운영진은 실제 입금 내역을 확인한 후 /결제확인 ${id} 를 사용하세요.`});
    return i.reply({content:"송금 완료 요청을 접수했어요. 운영진이 입금을 확인할 때까지 기다려 주세요.",ephemeral:true});
   }
  }

  // ===== 상품 선택 및 모달 =====
  if (i.isStringSelectMenu() && i.customId==="order_product") {
    const p=db.prepare("SELECT * FROM products WHERE id=? AND active=1").get(Number(i.values[0]));
    if (!p) return i.reply({content:"상품을 찾을 수 없어요.",ephemeral:true});
    const old=db.prepare("SELECT * FROM orders WHERE channel_id=? AND user_id=? AND status='draft' ORDER BY id DESC LIMIT 1").get(i.channelId,i.user.id);
    if (old) db.prepare("UPDATE orders SET product_id=?,product_name=?,unit_price=?,total=?,status='draft' WHERE id=?").run(p.id,p.name,p.price,p.price*old.quantity,old.id);
    else db.prepare("INSERT INTO orders(user_id,channel_id,product_id,product_name,quantity,nickname,unit_price,total,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)")
      .run(i.user.id,i.channelId,p.id,p.name,1,"",p.price,p.price,"draft",Date.now());
    const o=db.prepare("SELECT * FROM orders WHERE channel_id=? AND user_id=? AND status='draft' ORDER BY id DESC LIMIT 1").get(i.channelId,i.user.id);
    return i.update({embeds:[orderEmbed(o)],components:ticketComponents(db.prepare("SELECT * FROM products WHERE active=1").all())});
  }

  if (i.isModalSubmit() && ["order_quantity_modal","order_nickname_modal"].includes(i.customId)) {
    const o=db.prepare("SELECT * FROM orders WHERE channel_id=? AND user_id=? AND status='draft' ORDER BY id DESC LIMIT 1").get(i.channelId,i.user.id);
    if (!o) return i.reply({content:"수정할 주문이 없어요. 먼저 상품을 선택해 주세요.",ephemeral:true});
    const value=i.fields.getTextInputValue("value").trim();
    if (i.customId==="order_quantity_modal") {
      const q=Number(value);
      if (!Number.isInteger(q)||q<1||q>100) return i.reply({content:"수량은 1~100 사이의 정수여야 해요.",ephemeral:true});
      const p=db.prepare("SELECT * FROM products WHERE id=?").get(o.product_id);
      if (!p) return i.reply({content:"상품을 찾을 수 없어요.",ephemeral:true});
      db.prepare("UPDATE orders SET quantity=?,unit_price=?,total=? WHERE id=?").run(q,p.price,p.price*q,o.id);
    } else {
      if (value.length<2) return i.reply({content:"닉네임을 두 글자 이상 입력해 주세요.",ephemeral:true});
      db.prepare("UPDATE orders SET nickname=? WHERE id=?").run(value,o.id);
    }
    const updated=db.prepare("SELECT * FROM orders WHERE id=?").get(o.id);
    return i.update({embeds:[orderEmbed(updated)],components:ticketComponents(db.prepare("SELECT * FROM products WHERE active=1").all())});
  }
 } catch (err) {
   console.error("interaction error",err);
   const payload={content:"오류가 발생했어요. 운영진에게 문의해 주세요.",ephemeral:true};
   if (i.isRepliable()&&!i.replied&&!i.deferred) await i.reply(payload).catch(()=>{});
  }
});

(async()=>{
 const rest=new REST({version:"10"}).setToken(process.env.DISCORD_TOKEN);
 await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID,process.env.GUILD_ID),{body:commandDefs.map(c=>c.toJSON())});
 console.log("슬래시 명령어 등록 완료");
 await client.login(process.env.DISCORD_TOKEN);
})();
